<?php 
class PedidoDAOC {

    public function listarPedidos() {
        require_once("../dataBase/ConexionDB.php");
        require_once("../model/Pedido.php");

        $con = new ConexionDB("localhost","root","","cacproyecto");
        $con->conectar();
        $result = $con->ejecutar("SELECT * FROM pedidos");

        while ($pedido = $result->fetch_assoc()) {
            //todo: cargar todos los datos del pedido
            $pedObj = new Pedido($pedido["idpedido"],$pedido["nombre"],$pedido["apellido"],$pedido["usuario"],$pedido["mail"],$pedido["lugarentrega"],$pedido["localidad"],$pedido["provincia"],$pedido["codpostal"], "","","","","");

            $listPedidos[]=$pedObj;
        }

        return $listPedidos;

    }

}

?>